"""ColSON parser for Python 3."""

from .parser import dumps, loads
